/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package staffcalc;

import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author 20120106
 */
public class Angestellter {
    private float   gehalt,
                    ueberstundenSatz;
    
    //Sozialversicherung
    private static float    laufendEntgeltMonatlich,
                            laufendEntgeltTaeglich,
                            sonderZahlungen,
                            pendlerPauschale,
                            geringfuegigkeitsGrenze,
                            serviceEntgelt,
                            aufloesungsAbgabe;
    private static final float[]    SVDienstNehmer = new float[4],
                                    SVDienstGeber = new float[4];
//    private static float    kammerUmlage,
//                            wohnbauFoerderung,
//                            IESGZuschlag;
    
    //Beiträge und Abgaben
    private static float freiBetragDienstGeber;
    private static Map<String,Float> DGZuschlag = new TreeMap<>();
    private static float freiBetragKommunalSteuer;
    private static float DGAbgabeWien;
    private static final float[]    pendlerKlein = new float[4],
                                    pendlerGross = new float[4];
    
    //Lohnsteuer
    private static float pendlerEuro;
    private static float freiBetragZuschlaege,
                         freiBetragErhoeht,
                         freiBetragUeberstunden,
                         freiGrenzeSonstigeBezuege,
                         freiBetragSonstigeBezuege,
                         tagesGeld,
                         naechtigungsGeld,
                         kilometerGeldPkw,
                         kilometerGeldMitbefoerderung,
                         kilometerGeldMotorrad,
                         privatNutzungDienstGeberKfz,
                         gewerkschaftsBeitrag;
    
    //Effektiv-Tarif
    private static final float[]    absetzBetragKind = new float[6],
                                    grenzSteuerSatz = new float[4];
                                    
}
